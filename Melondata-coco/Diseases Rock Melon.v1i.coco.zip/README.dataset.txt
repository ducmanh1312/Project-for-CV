# Diseases Rock Melon > 2024-02-15 1:05am
https://universe.roboflow.com/rockmelon/diseases-rock-melon

Provided by a Roboflow user
License: CC BY 4.0

